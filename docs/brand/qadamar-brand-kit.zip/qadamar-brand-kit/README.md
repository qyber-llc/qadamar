# Qadamar brand prototypes

Open-source authorization by Qyber LLC. Tagline: **Every access decision. Explained.**

Open `index.html` for the English prototype gallery. `qadamar-brand-board.png` compares three directions:

1. **H Portal (recommended):** an H forming a doorway, a nod to the Hadamard gate.
2. **Q Circuit:** Qyber’s initial crossed by a circuit wire.
3. **Ket Door:** a doorway inspired by quantum ket notation.

`qadamar-mark.svg` and `qadamar-logo.svg` are the H Portal defaults. Light, dark and monochrome marks, a social preview, PNG exports and JSON design tokens are included. SVG wordmarks use system fonts; outline text before sending to print. These are prototypes, not a completed trademark or domain clearance.

The quantum reference describes the visual identity. The engine is classical and deterministic.

## Rename scope

The visible console name, browser title, favicon, repository introduction and brand assets now use Qadamar. The local checkout and existing GitHub remote retain their original names. Existing technical identifiers (Python imports, protocol URNs/headers, signing identities, storage keys and Lean namespaces) remain compatible; changing them requires a versioned migration. Historical records and third-party notices are preserved.
